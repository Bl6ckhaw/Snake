#include <iostream>
#include <SFML/System.hpp>

using namespace std;

int main()
{
    sf::RenderWindow windows(sf::VideoMode)

    return 0;
}
