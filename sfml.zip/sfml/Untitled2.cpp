#include <SFML/Graphics.hpp>
#include <iostream>
#include <cstdlib>
using namespace std;


int taille = 20;
int hauteur = taille*taille, largeur = taille*taille;
int longueurSnake = 3;
int dir = 1;

struct snake
{
    int x, y;
}s[100];

struct apple
{
    int x, y;
}a;

void action ()
{
    for (int i = longueurSnake; i>0; i--)
    {
        s[i].x = s[i-1].x;
        s[i].y = s[i-1].y;
    }

    if (dir==0) s[0].y -= 1;
    if (dir==1) s[0].x += 1;
    if (dir==2) s[0].y += 1;
    if (dir==3) s[0].x -= 1;

    if (s[0].x == a.x && s[0].y == a.y)
    {
        longueurSnake += 1;
        a.x = rand()%taille;
        a.y = rand()%taille;
    }
}

int main()
{
    sf::RenderWindow window(sf::VideoMode(largeur, hauteur), "Snake", sf::Style::Titlebar);
    window.setVerticalSyncEnabled(true);

    sf::RectangleShape serpent(sf::Vector2f(taille, taille));
    serpent.setFillColor(sf::Color::Green);

    sf::RectangleShape pomme (sf::Vector2f(taille, taille));
    pomme.setFillColor(sf::Color::Red);

    a.x = rand()%taille;
    a.y = rand()%taille;

    sf::Clock timer;

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch (event.type)
            {
                case sf::Event::KeyReleased:
                    if (event.key.code == sf::Keyboard::Escape)
                        window.close();
                    break;

            }

            if (timer.getElapsedTime().asMilliseconds()>200){
                action();
                timer.restart();
            }
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) dir = 0;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) dir = 1;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) dir = 2;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) dir = 3;

        window.clear();

        for (int i = 0; i<longueurSnake; i++)
        {
            serpent.setPosition (s[i].x*taille, s[i].y*taille);
            window.draw(serpent);
        }

        pomme.setPosition(a.x*taille, a.y*taille);
        window.draw(pomme);

        window.display();
    }
    return 0;
}
